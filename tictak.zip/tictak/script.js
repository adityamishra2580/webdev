document.addEventListener('DOMContentLoaded', () => {
    const board = document.getElementById('board');
    const winnerText = document.getElementById('winner');
    const cells = [];
    const resetButton = document.getElementById('reset-button');

    let currentPlayer = 'X';
    let winner = null;

    resetButton.addEventListener('click', resetGame);

    // Create the Tic-Tac-Toe board
    for (let i = 0; i < 9; i++) {
        const cell = document.createElement('div');
        cell.classList.add('cell');
        cell.dataset.index = i;
        cell.addEventListener('click', cellClick);
        cells.push(cell);
        board.appendChild(cell);
    }

    function cellClick(e) {
        const cell = e.target;
        const index = cell.dataset.index;

        if (!cells[index].textContent && !winner) {
            cells[index].textContent = currentPlayer;
            checkWinner();
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        }
    }

    function checkWinner() {
        const winningCombinations = [
            [0, 1, 2],
            [3, 4, 5],
            [6, 7, 8],
            [0, 3, 6],
            [1, 4, 7],
            [2, 5, 8],
            [0, 4, 8],
            [2, 4, 6]
        ];

        for (const combination of winningCombinations) {
            const [a, b, c] = combination;
            if (cells[a].textContent && cells[a].textContent === cells[b].textContent && cells[a].textContent === cells[c].textContent) {
                winner = cells[a].textContent;
                winnerText.textContent = `Player ${winner} wins!`;
                break;
            }
        }
    }

    function resetGame() {
        winner = null;
        winnerText.textContent = '';
        currentPlayer = 'X';
        cells.forEach(cell => {
            cell.textContent = '';
        });
    }

    const startButton = document.getElementById('start-button');
    const player1NameInput = document.getElementById('player1');
    const player2NameInput = document.getElementById('player2');

    startButton.addEventListener('click', () => {
        const player1Name = player1NameInput.value || 'Player 1';
        const player2Name = player2NameInput.value || 'Player 2';

        cells.forEach(cell => {
            cell.style.transform = 'scale(1)';
        });

        resetGame();
        player1NameInput.disabled = true;
        player2NameInput.disabled = true;
        startButton.disabled = true;

        document.getElementById('player-names').style.display = 'none';

        currentPlayer = 'X';
        document.getElementById('player1').value = player1Name;
        document.getElementById('player2').value = player2Name;
    });
});
